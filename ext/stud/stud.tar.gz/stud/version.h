#define STUD_VERSION "0.3-dev"
